export { defaultValidationRules } from "apollo-language-server/lib/errors/validation";
//# sourceMappingURL=defaultValidationRules.d.ts.map